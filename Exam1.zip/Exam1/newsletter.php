<!--
    Peter welter
    2/12/2020
    newsletter.php
    display form to user
-->
<form action="" method = "post">

    <label>Name: </label>
    <input type = "textbox" name="name">

    <br>

    <label> Phone Number: </label>
    <input type = "textbox" name="phone">

    <br> 

    <label> Email: </label>
    <input type = "textbox" name="email">

    <input type = "submit" value = "Submit">

</form>